"use client";

import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

interface CrosshairItem {
  id: number;
  name: string;
  category: string;
  code: string;
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  
  const [pendingCrosshairs, setPendingCrosshairs] = useState<CrosshairItem[]>([]);
  const [approvedCrosshairs, setApprovedCrosshairs] = useState<CrosshairItem[]>([]);
  
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [code, setCode] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Buradaki şifreyi kendi admin şifrenle değiştirebilirsin
    if (password === "admin123") {
      setIsAuthenticated(true);
      fetchData();
    } else {
      alert("Hatalı Şifre!");
    }
  };

  const fetchData = async () => {
    // Bekleyenler
    const { data: pending } = await supabase
      .from("pending_crosshairs")
      .select("*")
      .order("id", { ascending: false });

    if (pending) setPendingCrosshairs(pending);

    // Onaylananlar
    const { data: approved } = await supabase
      .from("approved_crosshairs")
      .select("*")
      .order("id", { ascending: false });

    if (approved) setApprovedCrosshairs(approved);
  };

  const handleAddDirect = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !category || !code) return alert("Tüm alanları doldurun!");

    const { error } = await supabase
      .from("approved_crosshairs")
      .insert([{ name, category, code }]);

    if (!error) {
      alert("Nişangah başarıyla eklendi!");
      setName("");
      setCategory("");
      setCode("");
      fetchData();
    } else {
      alert("Bir hata oluştu: " + error.message);
    }
  };

  const handleApprove = async (item: CrosshairItem) => {
    // Onaylananlar tablosuna ekle
    const { error: insertError } = await supabase
      .from("approved_crosshairs")
      .insert([{ name: item.name, category: item.category, code: item.code }]);

    if (insertError) {
      alert("Onaylanırken hata oluştu: " + insertError.message);
      return;
    }

    // Bekleyenlerden sil
    const { error: deleteError } = await supabase
      .from("pending_crosshairs")
      .delete()
      .eq("id", item.id);

    if (!deleteError) {
      fetchData();
    }
  };

  const handleDeletePending = async (id: number) => {
    const { error } = await supabase
      .from("pending_crosshairs")
      .delete()
      .eq("id", id);

    if (!error) fetchData();
  };

  const handleDeleteApproved = async (id: number) => {
    const { error } = await supabase
      .from("approved_crosshairs")
      .delete()
      .eq("id", id);

    if (!error) fetchData();
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
        <form onSubmit={handleLogin} className="bg-zinc-900 border border-zinc-800 p-8 rounded-2xl w-full max-w-md space-y-4 shadow-2xl">
          <h1 className="text-2xl font-bold text-center">Admin Girişi</h1>
          <input
            type="password"
            placeholder="Admin Şifresi"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full bg-black border border-zinc-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-zinc-600"
          />
          <button type="submit" className="w-full bg-white text-black font-semibold py-3 rounded-xl hover:bg-zinc-200 transition">
            Giriş Yap
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-8">
      <div className="max-w-6xl mx-auto space-y-12">
        <div className="flex justify-between items-center border-b border-zinc-800 pb-6">
          <h1 className="text-3xl font-extrabold">Admin Paneli</h1>
          <button
            onClick={() => setIsAuthenticated(false)}
            className="bg-zinc-900 hover:bg-zinc-800 text-zinc-300 px-4 py-2 rounded-xl text-sm transition border border-zinc-800"
          >
            Çıkış Yap
          </button>
        </div>

        {/* Nişangah Ekleme Formu */}
        <div className="bg-zinc-900/50 border border-zinc-800/80 p-6 rounded-2xl space-y-4">
          <h2 className="text-xl font-bold">Doğrudan Nişangah Ekle</h2>
          <form onSubmit={handleAddDirect} className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input
              type="text"
              placeholder="Oyuncu / Nişangah Adı"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-black border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-zinc-600"
            />
            <input
              type="text"
              placeholder="Kategori (Takım, Oyuncu vb.)"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="bg-black border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-zinc-600"
            />
            <input
              type="text"
              placeholder="CS2 Nişangah Kodu"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="bg-black border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-zinc-600"
            />
            <button type="submit" className="md:col-span-3 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold py-3 rounded-xl transition">
              Nişangahı Yayınla
            </button>
          </form>
        </div>

        {/* Onay Bekleyenler */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Onay Bekleyenler ({pendingCrosshairs.length})</h2>
          {pendingCrosshairs.length === 0 ? (
            <p className="text-zinc-500 text-sm">Bekleyen nişangah yok.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingCrosshairs.map((item) => (
                <div key={item.id} className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl flex flex-col justify-between space-y-3">
                  <div>
                    <h3 className="font-bold text-white">{item.name}</h3>
                    <p className="text-xs text-zinc-400">{item.category}</p>
                    <p className="text-xs text-zinc-500 font-mono mt-2 truncate">{item.code}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleApprove(item)}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-xl text-sm font-semibold transition"
                    >
                      Onayla
                    </button>
                    <button
                      onClick={() => handleDeletePending(item.id)}
                      className="flex-1 bg-red-600/20 hover:bg-red-600/30 text-red-400 py-2 rounded-xl text-sm font-semibold transition border border-red-500/20"
                    >
                      Reddet
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Yayındaki Nişangahlar */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Yayındaki Nişangahlar ({approvedCrosshairs.length})</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {approvedCrosshairs.map((item) => (
              <div key={item.id} className="bg-zinc-900 border border-zinc-800 p-5 rounded-2xl flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="font-bold text-white">{item.name}</h3>
                  <p className="text-xs text-zinc-400">{item.category}</p>
                  <p className="text-xs text-zinc-500 font-mono mt-2 truncate">{item.code}</p>
                </div>
                <button
                  onClick={() => handleDeleteApproved(item.id)}
                  className="bg-red-600/20 hover:bg-red-600/30 text-red-400 py-2 rounded-xl text-sm font-semibold transition border border-red-500/20"
                >
                  Siteden Kaldır
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}