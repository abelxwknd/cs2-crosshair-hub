"use client";

import { useState } from "react";

export default function TestUploadPage() {
  const [croppedImage, setCroppedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);

    const formData = new FormData();
    formData.append("image", file);

    try {
      const response = await fetch("/api/crop-crosshair", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const blob = await response.blob();
        const croppedImageUrl = URL.createObjectURL(blob);
        setCroppedImage(croppedImageUrl);
      } else {
        alert("Resim işlenirken bir sorun oluştu.");
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-8 flex flex-col items-center justify-center space-y-6">
      <h1 className="text-2xl font-bold">CS2 Ekran Görüntüsünden Crosshair Kesme</h1>
      
      <input
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="block w-full max-w-xs text-sm text-zinc-400 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-zinc-800 file:text-white hover:file:bg-zinc-700 cursor-pointer"
      />

      {loading && <p className="text-yellow-400 text-sm">Resim taranıyor ve crosshair kesiliyor...</p>}

      {croppedImage && (
        <div className="space-y-2 text-center">
          <p className="text-emerald-400 font-semibold">Sonuç:</p>
          <img
            src={croppedImage}
            alt="Cropped Crosshair"
            className="w-64 h-64 rounded-2xl border border-zinc-800 object-cover shadow-2xl"
          />
        </div>
      )}
    </div>
  );
}