"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import toast, { Toaster } from "react-hot-toast";
import Link from "next/link";

type Crosshair = {
  id: number;
  name: string;
  slug: string;
  code: string;
  image: string | null;
  likes: number;
  copies: number;
  views: number;
  player: string | null;
  team: string | null;
  created_at: string;
};

export default function Home() {
  const [crosshairs, setCrosshairs] = useState<Crosshair[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [favorites, setFavorites] = useState<number[]>([]);
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  useEffect(() => {
    loadCrosshairs();
    const saved = localStorage.getItem("favorites");
    if (saved) {
      setFavorites(JSON.parse(saved));
    }
  }, []);

  async function loadCrosshairs() {
    const { data, error } = await supabase
      .from("approved_crosshairs")
      .select("*")
      .order("likes", { ascending: false });

    if (!error && data) {
      setCrosshairs(data);
    }
  }

  const copyCode = async (
    id: number,
    code: string,
    currentCopies: number
  ) => {
    navigator.clipboard.writeText(code);

    await supabase
      .from("approved_crosshairs")
      .update({ copies: currentCopies + 1 })
      .eq("id", id);

    toast.success("Crosshair kopyalandı");
    loadCrosshairs();
  };

  const likeCrosshair = async (id: number, currentLikes: number) => {
    const liked = localStorage.getItem(`liked-${id}`);

    if (liked) {
      toast.error("Bu crosshair'i zaten beğendin");
      return;
    }

    await supabase
      .from("approved_crosshairs")
      .update({ likes: currentLikes + 1 })
      .eq("id", id);

    localStorage.setItem(`liked-${id}`, "true");
    toast.success("Beğeni eklendi ❤️");
    loadCrosshairs();
  };

  const toggleFavorite = (id: number) => {
    let updated;
    if (favorites.includes(id)) {
      updated = favorites.filter((item) => item !== id);
      toast.error("Favorilerden çıkarıldı");
    } else {
      updated = [...favorites, id];
      toast.success("Favorilere eklendi ⭐");
    }

    setFavorites(updated);
    localStorage.setItem("favorites", JSON.stringify(updated));
  };

  const filteredCrosshairs = [...crosshairs]
    .filter((crosshair) =>
      crosshair.name.toLowerCase().includes(search.toLowerCase())
    )
    .filter((crosshair) => {
      if (filter === "favorites") {
        return favorites.includes(crosshair.id);
      }
      if (filter === "new") {
        return (
          new Date(crosshair.created_at) >
          new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        );
      }
      return true;
    })
    .sort((a, b) => {
      if (filter === "likes") return b.likes - a.likes;
      if (filter === "copies") return b.copies - a.copies;
      return 0;
    });

  const topCrosshairs = [...crosshairs]
    .sort((a, b) => b.likes - a.likes)
    .slice(0, 3);
  const mostViewed = [...crosshairs]
    .sort((a, b) => (b.views || 0) - (a.views || 0))
    .slice(0, 3);
  const mostCopied = [...crosshairs]
    .sort((a, b) => b.copies - a.copies)
    .slice(0, 3);
  const mostLiked = [...crosshairs]
    .sort((a, b) => b.likes - a.likes)
    .slice(0, 3);

  return (
    <>
      <Toaster position="top-center" />

      <main className="min-h-screen bg-black text-white relative overflow-hidden">
        {/* Glow */}
        <div className="fixed top-0 left-0 w-[500px] h-[500px] bg-red-600/10 blur-[180px] pointer-events-none" />
        <div className="fixed bottom-0 right-0 w-[500px] h-[500px] bg-blue-600/10 blur-[180px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 py-12">
          {/* HERO */}
          <div className="text-center mb-16">
            <h1 className="text-6xl md:text-7xl font-black bg-gradient-to-r from-red-500 via-white to-red-500 bg-clip-text text-transparent">
              CS2 Crosshair Hub
            </h1>

            <p className="text-zinc-400 text-lg mt-4 max-w-2xl mx-auto">
              Profesyonel oyuncuların ve topluluğun kullandığı Counter-Strike 2
              crosshair kodlarını keşfet.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-10 max-w-4xl mx-auto">
              <div className="bg-white/5 backdrop-blur-md border border-zinc-800 rounded-2xl p-5">
                <p className="text-zinc-500 text-sm">🎯 Toplam Crosshair</p>
                <h3 className="text-3xl font-bold text-red-500">
                  {crosshairs.length}
                </h3>
              </div>

              <div className="bg-white/5 backdrop-blur-md border border-zinc-800 rounded-2xl p-5">
                <p className="text-zinc-500 text-sm">❤️ Toplam Beğeni</p>
                <h3 className="text-3xl font-bold text-red-500">
                  {crosshairs.reduce((a, b) => a + b.likes, 0)}
                </h3>
              </div>

              <div className="bg-white/5 backdrop-blur-md border border-zinc-800 rounded-2xl p-5">
                <p className="text-zinc-500 text-sm">👑 Pro Oyuncu</p>
                <h3 className="text-3xl font-bold text-red-500">
                  {crosshairs.length}
                </h3>
              </div>
            </div>

            {/* BUTONLAR (Güncellenmiş Alan) */}
            <div className="flex justify-center gap-4 mt-8 flex-wrap">
              <button
                onClick={() => setIsGuideOpen(true)}
                className="bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 px-6 py-3 rounded-xl font-semibold transition flex items-center gap-2"
              >
                ❓ Kod Nasıl Kullanılır?
              </button>

              <Link
                href="/generator"
                className="bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-xl font-semibold transition"
              >
                🎨 Crosshair Generator
              </Link>

              <Link
                href="/compare"
                className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-xl font-semibold transition"
              >
                ⚔️ Karşılaştır
              </Link>

              <a
                href="/submit"
                className="bg-red-600 hover:bg-red-700 px-6 py-3 rounded-xl font-semibold transition"
              >
                Crosshair Gönder
              </a>

              <a
                href="/admin"
                className="bg-white/5 backdrop-blur-md border border-zinc-800 px-6 py-3 rounded-xl font-semibold hover:border-red-500 transition"
              >
                Admin Panel
              </a>
            </div>
          </div>

          {/* TOP 3 PREMIUM */}
          <div className="mb-16">
            <h2 className="text-4xl font-black mb-8 text-center">
              🏆 Top Crosshairs
            </h2>

            <div className="grid md:grid-cols-3 gap-6">
              {topCrosshairs.map((crosshair, index) => (
                <div
                  key={crosshair.id}
                  className={`relative overflow-hidden rounded-3xl p-6 border backdrop-blur-xl transition-all hover:scale-105 ${
                    index === 0
                      ? "bg-yellow-500/10 border-yellow-500 shadow-[0_0_40px_rgba(234,179,8,0.25)]"
                      : index === 1
                      ? "bg-gray-300/10 border-gray-400 shadow-[0_0_40px_rgba(156,163,175,0.25)]"
                      : "bg-orange-500/10 border-orange-500 shadow-[0_0_40px_rgba(249,115,22,0.25)]"
                  }`}
                >
                  <div className="absolute top-3 right-3 text-4xl">
                    {index === 0 ? "🥇" : index === 1 ? "🥈" : "🥉"}
                  </div>

                  <div className="text-5xl font-black mb-4">#{index + 1}</div>

                  <h3 className="text-3xl font-bold">{crosshair.name}</h3>
                  <div className="text-center mt-3 text-zinc-400">
                    👤 {crosshair.player || crosshair.name}
                    <br />
                    🏆 {crosshair.team || "Bilinmeyen Takım"}
                  </div>

                  <p className="text-red-400 font-semibold mt-3">
                    ❤️ {crosshair.likes} Beğeni
                  </p>

                  <p className="text-zinc-400 mt-1">
                    📋 {crosshair.copies} Kopyalama
                  </p>

                  <button
                    onClick={() =>
                      copyCode(crosshair.id, crosshair.code, crosshair.copies)
                    }
                    className="mt-6 w-full bg-white/10 hover:bg-white/20 border border-white/20 py-3 rounded-xl font-semibold transition"
                  >
                    📋 Kodu Kopyala
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* DISCOVER */}
          <div className="mb-12">
            <h2 className="text-3xl font-black mb-6">🔥 Keşfet</h2>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
                <h3 className="text-xl font-bold mb-4">
                  👁 En Çok Görüntülenen
                </h3>
                {mostViewed.map((item, index) => (
                  <div
                    key={item.id}
                    className="flex justify-between py-2 border-b border-zinc-800"
                  >
                    <span>
                      #{index + 1} {item.name}
                    </span>
                    <span className="text-zinc-400">👁 {item.views}</span>
                  </div>
                ))}
              </div>

              <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
                <h3 className="text-xl font-bold mb-4">
                  📋 En Çok Kopyalanan
                </h3>
                {mostCopied.map((item, index) => (
                  <div
                    key={item.id}
                    className="flex justify-between py-2 border-b border-zinc-800"
                  >
                    <span>
                      #{index + 1} {item.name}
                    </span>
                    <span className="text-zinc-400">📋 {item.copies}</span>
                  </div>
                ))}
              </div>

              <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6">
                <h3 className="text-xl font-bold mb-4">❤️ En Çok Beğenilen</h3>
                {mostLiked.map((item, index) => (
                  <div
                    key={item.id}
                    className="flex justify-between py-2 border-b border-zinc-800"
                  >
                    <span>
                      #{index + 1} {item.name}
                    </span>
                    <span className="text-red-400">❤️ {item.likes}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* SEARCH */}
          <div className="mb-10">
            <input
              type="text"
              placeholder="Oyuncu ara... (donk, m0NESY, s1mple)"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white/5 backdrop-blur-md border border-zinc-800 rounded-xl p-4 outline-none focus:border-red-500"
            />
          </div>

          {/* FILTERS */}
          <div className="flex flex-wrap gap-3 mb-10">
            <button
              onClick={() => setFilter("all")}
              className={`px-4 py-2 rounded-xl border ${
                filter === "all"
                  ? "bg-red-600 border-red-600"
                  : "bg-zinc-900 border-zinc-700"
              }`}
            >
              Tümü
            </button>

            <button
              onClick={() => setFilter("new")}
              className={`px-4 py-2 rounded-xl border ${
                filter === "new"
                  ? "bg-orange-500 border-orange-500"
                  : "bg-zinc-900 border-zinc-700"
              }`}
            >
              🔥 Yeni
            </button>

            <button
              onClick={() => setFilter("likes")}
              className={`px-4 py-2 rounded-xl border ${
                filter === "likes"
                  ? "bg-red-500 border-red-500"
                  : "bg-zinc-900 border-zinc-700"
              }`}
            >
              ❤️ Popüler
            </button>

            <button
              onClick={() => setFilter("copies")}
              className={`px-4 py-2 rounded-xl border ${
                filter === "copies"
                  ? "bg-blue-600 border-blue-600"
                  : "bg-zinc-900 border-zinc-700"
              }`}
            >
              📋 En Çok Kopyalanan
            </button>

            <button
              onClick={() => setFilter("favorites")}
              className={`px-4 py-2 rounded-xl border ${
                filter === "favorites"
                  ? "bg-yellow-500 text-black border-yellow-500"
                  : "bg-zinc-900 border-zinc-700"
              }`}
            >
              ⭐ Favorilerim
            </button>
          </div>

          {/* CROSSHAIRS LIST */}
          <div className="grid sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-10">
            {filteredCrosshairs.map((crosshair, index) => (
              <div
                key={crosshair.id}
                className="group flex flex-col bg-gradient-to-b from-zinc-900/80 to-zinc-950/80 backdrop-blur-xl border border-zinc-800 rounded-3xl p-5 relative"
              >
                <button
                  onClick={() => toggleFavorite(crosshair.id)}
                  className="absolute top-3 right-3 bg-zinc-900 border border-zinc-700 px-3 py-1 rounded-xl hover:border-yellow-500 transition z-10"
                >
                  {favorites.includes(crosshair.id) ? "⭐" : "☆"}
                </button>
                <div className="absolute top-3 left-3 bg-zinc-900 border border-zinc-700 px-2 py-1 rounded-full text-xs font-bold z-10">
                  #{index + 1}
                </div>

                {new Date(crosshair.created_at) >
                  new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) && (
                  <div className="absolute top-12 right-3 bg-orange-500 text-white text-xs px-2 py-1 rounded-full z-10">
                    🔥 Yeni
                  </div>
                )}

                <div className="bg-black border border-zinc-800 rounded-2xl p-5 text-center mt-8">
                  <p className="text-zinc-500 text-sm">👁 Görüntülenme</p>
                  <p className="text-3xl font-bold">{crosshair.views}</p>
                </div>

                <div className="my-5">
                  <Link href={`/crosshair/${crosshair.slug}`}>
                    <img
                      src={
                        crosshair.image
                          ? `/crosshairs/${crosshair.image}`
                          : "/crosshairs/default.png"
                      }
                      className="w-full h-44 object-contain bg-zinc-900 rounded-2xl border border-zinc-800 p-2 cursor-pointer"
                      alt={crosshair.name}
                    />
                  </Link>
                </div>

                <Link href={`/crosshair/${crosshair.slug}`}>
                  <h2 className="text-2xl font-bold text-center hover:text-red-500 transition">
                    {crosshair.name}
                  </h2>
                </Link>

                <div className="mt-4 bg-zinc-950 rounded-lg p-3 border border-zinc-800">
                  <p className="text-xs text-zinc-500 mb-2">Crosshair Kodu</p>
                  <p className="text-zinc-300 text-xs text-center overflow-hidden text-ellipsis whitespace-nowrap">
                    {crosshair.code}
                  </p>
                </div>

                <p className="text-zinc-400 text-center text-sm mt-3">
                  📋 {crosshair.copies} Kopyalama
                </p>

                <div className="flex justify-center mt-4 mb-2">
                  <button
                    onClick={() =>
                      likeCrosshair(crosshair.id, crosshair.likes)
                    }
                    className="bg-zinc-900 border border-zinc-700 px-4 py-2 rounded-xl text-red-500 font-semibold"
                  >
                    ❤️ {crosshair.likes} Beğeni
                  </button>
                </div>

                <button
                  onClick={() =>
                    copyCode(crosshair.id, crosshair.code, crosshair.copies)
                  }
                  className="mt-auto w-full bg-red-600 hover:bg-red-700 py-3 rounded-2xl font-semibold"
                >
                  📋 Kodu Kopyala
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* REHBER MODALI (Örnek) */}
        {isGuideOpen && (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 max-w-lg w-full relative">
              <h3 className="text-2xl font-bold mb-4">❓ Kod Nasıl Kullanılır?</h3>
              <p className="text-zinc-400 text-sm mb-4">
                Kopyaladığın crosshair kodunu CS2 içerisindeki oyun konsoluna (`~` tuşu ile açılır) yapıştırarak anında kullanabilirsin.
              </p>
              <button
                onClick={() => setIsGuideOpen(false)}
                className="w-full bg-red-600 hover:bg-red-700 py-3 rounded-xl font-semibold"
              >
                Anladım
              </button>
            </div>
          </div>
        )}
      </main>
    </>
  );
}